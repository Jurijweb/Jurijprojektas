<?php
  require __DIR__ . '/../app/src/app.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interneto svetainių kūrimas</title>
    <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css'>

    <link rel="stylesheet" href="../app/css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
    <script src="../app/js/main.js"></script>

</head>

<body>
    <?php
   include('../app/views/header.php');
   include('../app/views/content.php');
   include('../app/views/footer.php');
   
   ?>


</body>

</html>
