<?php
if(isset($_POST['submit'])) {
$vardas = trim($_POST['vardas']);
$email = trim($_POST['email']);
$message = trim($_POST['message']);


if(!empty($vardas) && !empty($email) && !empty($message)) {
    if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $from = "$email";
        $to = "macinkevic85@gmail.com";
        $subject = "Nauja žinutė";
        $autorius = 'Nuo: ' . $vardas . ', ' . $email;
        $zinute = htmlspecialchars($message);
        mail($from, $to, $subject, $autorius, $zinute);
        echo '<script>alert "Dekojame. Jusu zinute gauta. Netrukus susisieksime".</script>';
    }
}

include ('db.php');
}

?>


<?php
//    if(isset($_POST['submit'])) {
//    $to = "macik85@yahoo.com"; // this is your Email address
//    $email = $_POST['email']; // this is the sender's Email address
//    $first_name = $_POST['vardas'];
////    $subject = $_POST['subject'];
//    $message = $_POST['message'];
//         
//   if(!empty($first_name) && !empty($email) && !empty($message) && !empty($subject)) {
//    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
//    $headers = "From:" . "$email";
//    mail($to,$subject,$message,$headers);
//
//        }
//    }
//        
//include ('db.php');
//        
//}