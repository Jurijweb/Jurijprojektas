 <header>
     <div class="container">
         <div class="heading clearfix">
             <div class="logo" alt="JUR MAC">
                 <span>JUR</span> MAC
             </div>
             <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

             <div class="topnav" id="myTopnav">
                 <a href="#header" class="active">Pradžia</a>
                 <a href="#about">Apie</a>
                  <a href="#portfolio">Mūsų darbai</a>
<!--                 <a href="#header">Pradžia</a>s-->
                 <a href="#services">Paslaugos</a>
                 <a href="#contact">Kontaktai</a>
                 
                 
                 <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                     <i class="fa fa-bars"></i>
                 </a>
             </div>
             
         </div>

         <div class="titles">
             <h1 class="asa">
                 Profesionalus<br>
                 <span>interneto svetainių</span> <br> kūrimas
             </h1>
         </div>
         <a class="button" href="#about">Sužinoti daugiau</a>
     </div>
 </header>
