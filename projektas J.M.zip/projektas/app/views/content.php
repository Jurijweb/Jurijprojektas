<section id="services">
    <div class="container">
        <div class="title">
            <h2>
                Paslaugos
            </h2>
            <p>
                Proin iaculis purus consequat sem cure.
            </p>
        </div>
        <div class="services clearfix">
            <div class="services__item">
                <img src="../app/img/icon1.png" alt="Services">
                <h3>E-Commerce</h3>
                <p>
                    Proin iaculis purus consequat sem cure digni ssim. Donec porttitora entum suscipit
                    aenean rhoncus posuere odio in tincidunt.
                </p>
            </div>
            <div class="services__item">
                <img src="../app/img/icon2.png" alt="Services">
                <h3>Web dizainas</h3>
                <p>
                    Proin iaculis purus consequat sem cure digni ssim. Donec porttitora entum suscipit
                    aenean rhoncus posuere odio in tincidunt.
                </p>
            </div>
            <div class="services__item">
                <img src="../app/img/icon3.png" alt="Services">
                <h3>Web apsauga</h3>
                <p>
                    Proin iaculis purus consequat sem cure digni ssim. Donec porttitora entum suscipit
                    aenean rhoncus posuere odio in tincidunt.
                </p>
            </div>
        </div>
    </div>
</section>
<section id="portfolio">
    <div class="container">
        <div class="title">
            <h2>
                Mūsų darbai
            </h2>
            <p>
                Proin iaculis purus consequat sem cure.
            </p>
        </div>
        <div class="works clearfix">
            <img src="../app/img/img1.jpg" alt="Work">
            <img src="../app/img/img2.jpg" alt="Work">
            <img src="../app/img/img3.jpg" alt="Work">
        </div>
    </div>
</section>

<section id="about">
    <div class="container">
        <div class="title">
            <h2>
                Apie
            </h2>
            <p>
                Proin iaculis purus consequat sem cure.
            </p>
        </div>
        <div class="about clearfix">
            <div class="about__item1">
                <img src="../app/img/about1.jpg" alt="About">
                <div class="block1">
                    <h3>July 2010 <br>Our Humble Beginnings</h3>
                    <p>
                        Proin iaculis purus consequat sem cure
                        digni ssim. Donec porttitora entum suscipit
                        aenean rhoncus posuere odio in tincidunt. Proin
                        iaculis purus consequat sem cure digni
                        ssim. Donec porttitora entum suscipit.
                    </p>
                </div>
            </div>
            <div class="about__item2">
                <img src="../app/img/about2.jpg" alt="About">
                <div class="block2">
                    <h3>January 2011<br>Facing Startup Battles</h3>
                    <p>
                        Proin iaculis purus consequat sem cure
                        digni ssim. Donec porttitora entum suscipit
                        aenean rhoncus posuere odio in tincidunt. Proin
                        iaculis purus consequat sem cure digni
                        ssim. Donec porttitora entum suscipit.
                    </p>
                </div>
            </div>
            <div class="about__item3">
                <img src="../app/img/about3.jpg" alt="About">
                <div class="block3">
                    <h3>December 2012<br>Enter The Dark Days</h3>
                    <p>
                        Proin iaculis purus consequat sem cure
                        digni ssim. Donec porttitora entum suscipit
                        aenean rhoncus posuere odio in tincidunt.> Proin
                        iaculis purus consequat sem cure digni
                        ssim. Donec porttitora entum suscipit.
                    </p>
                </div>
            </div>
            <div class="about__item4">
                <img src="../app/img/about4.jpg" alt="About">
                <div class="block4">
                    <h3>february 2014<br>Our Triumph</h3>
                    <p>
                        Proin iaculis purus consequat sem cure
                        digni ssim. Donec porttitora entum suscipit
                        aenean rhoncus posuere odio in tincidunt.Proin
                        iaculis purus consequat sem cure digni
                        ssim. Donec porttitora entum suscipit.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="contact">
    <div class="title">
        <h2>
            Kontaktai
        </h2>
    </div>
    <div class="wrapper">

        <main>
            <h3>Užsisakyti paslaugas</h3>
            <form class="form" action="index.php" method="post">

                <p><input class=cell type="text" name="vardas" placeholder="Jūsų vardas" required></p>
                <p><input class=cell type="email" name="email" placeholder="Jūsų el. pašto adresas" required></p>
                <textarea class="cell_message" rows="10" cols="45" name="message" placeholder="Jūsų žinutė..." required></textarea>
                <p><button name="submit" type="submit" class="button act">Siųsti</button></p>
            </form>
        </main>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d18444.184994332165!2d25.264004308466102!3d54.700418987738736!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46dd915751bd7cd9%3A0x7feb25790f366e70!2sAKROPOLIS%20Vilnius!5e0!3m2!1sen!2slt!4v1586209906033!5m2!1sen!2slt" width="400" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0" class="maps">
        </iframe>
    </div>

    <ul class="socialIcons">
        <li><a href="https://www.facebook.com/" target="_blank" class="facebook"><i class="fa fa-facebook "></i></a></li>
        <li><a href="https://www.twitter.com/" target="_blank" class="twitter"><i class="fa fa-twitter"></i></a></li>
        <li><a href="https://www.instagram.com/" target="_blank" class="instagram"><i class="fa fa-instagram"></i></a></li>
        <li><a href="https://www.youtube.com/" target="_blank" class="youtube"><i class="fa fa-youtube"></i></a></li>
    </ul>

</section>
