<footer>

        <div class="footer-logo">
            <span>JUR</span> MAC
        </div>
        <div class="copyright">
            &copy; <?php echo date("Y"); ?> Visos teisės saugomos.
        </div>


        <p class="phone"><img class="phone_icon" src="../app/img/phone.png" alt="telefono numeris"> <a href="tel:+37067659659" target="_blank"><span>+3706 76 59 659</span>
            </a></p>

        <p class="mail"><img class="mail_icon" src="../app/img/mail.png" alt="El.paštas"><a href="mailto:info@jurmac.lt" target="_blank"> <span>info@jurmac.lt</span></a></p>


    </footer>
